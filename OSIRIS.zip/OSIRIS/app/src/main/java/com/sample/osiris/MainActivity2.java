package com.sample.osiris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity2 extends AppCompatActivity {
    ImageView view11;
    ImageView view12;
    ImageView view13;
    ImageView view15;
    ImageView view16;
    ImageView view17;

    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btn = findViewById(R.id.button7);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent h = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(h);
            }
        });

        view11 = findViewById(R.id.imageView11);
        view11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this, MainActivity4.class);
                startActivity(i);
            }
        });
        view12 = findViewById(R.id.imageView12);
        view12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this, MainActivity5.class);
                startActivity(i);
            }
        });
        view13 = findViewById(R.id.imageView13);
        view13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this, MainActivity6.class);
                startActivity(i);
            }
        });
        view15 = findViewById(R.id.imageView15);
        view15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this, MainActivity7.class);
                startActivity(i);
            }
        });
        view16 = findViewById(R.id.imageView16);
        view16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this, MainActivity8.class);
                startActivity(i);
            }
        });
        view17 = findViewById(R.id.imageView17);
        view17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this, MainActivity9.class);
                startActivity(i);
            }
        });

    }
}