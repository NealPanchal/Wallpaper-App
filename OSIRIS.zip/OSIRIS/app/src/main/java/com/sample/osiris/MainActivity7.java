package com.sample.osiris;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.IOException;

public class MainActivity7 extends AppCompatActivity {
    ImageView imgView1;
    Button btnSet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        btnSet = (Button) findViewById(R.id.btnSetWallpaper);
        imgView1 = (ImageView) findViewById(R.id.imagee);
        imgView1.setImageResource(R.drawable.e);
        btnSet.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View view) {
                WallpaperManager myWallpaperManager = WallpaperManager.getInstance(MainActivity7.this);
                try {
                    myWallpaperManager.setResource(R.drawable.e);
                    Bitmap bitmap = BitmapFactory.decodeResource(MainActivity7.this.getResources(),R.drawable.e);
                    myWallpaperManager.setBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}