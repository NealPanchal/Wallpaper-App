package com.sample.osiris;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.IOException;

public class MainActivity4 extends AppCompatActivity {

    ImageView imgView;
    Button btnSet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        btnSet = (Button) findViewById(R.id.btnSetWallpaper);
        imgView = (ImageView) findViewById(R.id.imagea);
        imgView.setImageResource(R.drawable.d);
        btnSet.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View view) {
                WallpaperManager myWallpaperManager = WallpaperManager.getInstance(MainActivity4.this);
                try {
                    myWallpaperManager.setResource(R.drawable.d);
                    Bitmap bitmap = BitmapFactory.decodeResource(MainActivity4.this.getResources(),R.drawable.d);
                    myWallpaperManager.setBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}