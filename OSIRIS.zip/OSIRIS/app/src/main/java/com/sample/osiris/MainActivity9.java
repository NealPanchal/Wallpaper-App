package com.sample.osiris;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.IOException;

public class MainActivity9 extends AppCompatActivity {
    ImageView imgView1;
    Button btnSet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main9);
        btnSet = (Button) findViewById(R.id.btnSetWallpaper);
        imgView1 = (ImageView) findViewById(R.id.imagej);
        imgView1.setImageResource(R.drawable.j);
        btnSet.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View view) {
                WallpaperManager myWallpaperManager = WallpaperManager.getInstance(MainActivity9.this);
                try {
                    myWallpaperManager.setResource(R.drawable.j);
                    Bitmap bitmap = BitmapFactory.decodeResource(MainActivity9.this.getResources(),R.drawable.j);
                    myWallpaperManager.setBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}